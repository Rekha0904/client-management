import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DemoserviceService {

  constructor() { }
  mobiles=['redmi','iphone','samsung','OPPO']



}

/***************************************************************************************************
 * Zone JS is required by Angular.
 */
import 'zone.js';  // Included with Angular CLI

/***************************************************************************************************
 * BROWSER POLYFILLS
 */

/** IE11 requires the following for NgClass support on SVG elements */
// import 'classlist.js';  // Run `npm install --save classlist.js`.

 /** IE10 and IE11 requires the following for the Reflect API. */
// import 'core-js/es/reflect';

/**
 * Web Animations `@angular/platform-browser/animations`
 * Only required if AnimationBuilder is used within the application and using IE/Edge or Safari.
 * Standard animation support in Angular DOES NOT require any polyfills (as of Angular 6.0).
 **/
// import 'web-animations-js';  // Run `npm install --save web-animations-js`.

/***************************************************************************************************
 * APPLICATION IMPORTS
 */

/**
 * Date, currency, decimal and percent pipes.
 * Required for: All but Chrome, Firefox, Edge, IE11 and Safari 10
 **/
// import 'intl';  // Run `npm install --save intl`.
import { Component } from '@angular/core';

import { AuthService } from '../auth.service';

@Component({
  selector: 'app-sample-insert',
  templateUrl: './sample-insert.component.html',
  styleUrl: './sample-insert.component.css'
})
export class SampleInsertComponent {
  constructor(private authService: AuthService) { }
  insertSampleData() {
    // Register users
    this.authService.register('John Doe', 'john@example.com', 'password123', 'password123').subscribe(
      response => {
        console.log('User John registered', response);
      },
      error => {
        console.error('Error registering John', error);
      }
    );

    this.authService.register('Jane Smith', 'jane@example.com', 'password123', 'password123').subscribe(
      response => {
        console.log('User Jane registered', response);
      },
      error => {
        console.error('Error registering Jane', error);
      }
    );

    // Login users to create login records
    this.authService.login('john@example.com', 'password123').subscribe(
      response => {
        console.log('User John logged in', response);
      },
      error => {
        console.error('Error logging in John', error);
      }
    );

    this.authService.login('jane@example.com', 'password123').subscribe(
      response => {
        console.log('User Jane logged in', response);
      },
      error => {
        console.error('Error logging in Jane', error);
      }
    );
    this.authService.scheduleMeeting(1, 'Project Kickoff', 5, '2024-11-01T10:00:00').subscribe(
      response => {
        console.log('Meeting scheduled for John', response);
      },
      error => {
        console.error('Error scheduling meeting for John', error);
      }
    );

    this.authService.scheduleMeeting(2, 'Team Sync', 3, '2024-11-02T14:00:00').subscribe(
      response => {
        console.log('Meeting scheduled for Jane', response);
      },
      error => {
        console.error('Error scheduling meeting for Jane', error);
      }
    );
  }
}






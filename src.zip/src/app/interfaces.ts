export interface AuthResponse {
    success: boolean;
    message?: string;  // Optional field for any additional messages
  }
  
  export interface ScheduleResponse {
    success: boolean;
    message?: string;  // Optional field for any additional messages
  }
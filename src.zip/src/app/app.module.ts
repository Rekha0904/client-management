import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { AuthService } from './auth.service';

import { AppRoutingModule } from './app-routing.module';
import { TestPipe } from './test.pipe';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { FormsModule } from '@angular/forms';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import {RouterModule, Routes} from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { ScheduleMeetingComponent } from './schedule-meeting/schedule-meeting.component';
import { HttpClientModule } from '@angular/common/http';
import { SampleInsertComponent } from './sample-insert/sample-insert.component';

const routes:Routes=
[
  {path:'about',component:AboutComponent},
  {path:'contact',component:ContactComponent}
]


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    TestPipe,
    ContactComponent,
    RegisterComponent,
    LoginComponent,
    ScheduleMeetingComponent,
    SampleInsertComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule 

  ],
  providers: [AuthService,
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

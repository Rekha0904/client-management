export const environment = {
    production: true,
    // Add other environment-specific variables here
};

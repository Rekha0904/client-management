import { Component,  OnInit  } from '@angular/core';
import { DemoserviceService } from '../demoservice.service';


@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrl: './about.component.css'
})
export class AboutComponent implements OnInit {
  mobilefromservice: any;
  
  constructor(private ds:DemoserviceService) { }


  ngOnInit(): void {
  
  this.mobilefromservice=this.ds.mobiles;
  }
  addmobile(){
    this.ds.mobiles.push("nokia")
  }

  

}

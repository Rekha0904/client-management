import { Component , OnInit } from '@angular/core';
import { DemoserviceService } from '../demoservice.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit{
  mobilefromservice: any;
  constructor(private ds:DemoserviceService) { }


  ngOnInit(): void {
  
  this.mobilefromservice=this.ds.mobiles;
}

}

import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';
import { ScheduleResponse } from '../interfaces';
import { Router } from '@angular/router';



@Component({
  selector: 'app-schedule-meeting',
  templateUrl: './schedule-meeting.component.html',
  styleUrls: ['./schedule-meeting.component.css']
})
export class ScheduleMeetingComponent {
  topic!: string;
  numberOfPeople!: number;
  date!: string;
  time!: string;

  constructor(private meetingService: AuthService, private router: Router) { }

  onSubmit() {
    const userId = 1; // Replace this with the actual user ID from your authentication system
    const datetime = `${this.date}T${this.time}`; // Combine date and time to create a datetime string

    this.meetingService.scheduleMeeting(userId, this.topic, this.numberOfPeople, datetime).subscribe(
      response => {
        console.log('Meeting scheduled successfully', response);
        this.router.navigate(['/']);
      },
      error => {
        console.error('Error scheduling meeting', error);
      }
    );
  }
}
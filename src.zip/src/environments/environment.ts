export const environment = {
    production: false,
    // Add other environment-specific variables here
};

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SampleInsertComponent } from './sample-insert.component';

describe('SampleInsertComponent', () => {
  let component: SampleInsertComponent;
  let fixture: ComponentFixture<SampleInsertComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SampleInsertComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SampleInsertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
